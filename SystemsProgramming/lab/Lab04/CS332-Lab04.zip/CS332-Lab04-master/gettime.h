#ifndef _GETTIME_H_
#include <stdio.h>
#include <sys/time.h>
double gettime(void);
#endif
